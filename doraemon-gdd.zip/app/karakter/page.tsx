import Image from "next/image"

// Data karakter utama
const mainCharacters = [
  {
    id: "nobita",
    name: "Nobita Nobi",
    description:
      "Anak laki-laki yang canggung dan malas, namun berhati baik. Dalam game ini, Nobita bertugas mengelola pertanian yang rusak.",
    location: "Rumah pertanian di Natura",
    favoriteItem: "Dorayaki",
    likedItems: ["Sunflower", "Watermelon", "Udon", "Napa Cabbage"],
  },
  {
    id: "doraemon",
    name: "Doraemon",
    description: "Robot kucing dari abad ke-22 yang membantu Nobita dengan alat-alat ajaibnya.",
    location: "Rumah Wali Kota, membantu administrasi desa",
    favoriteItem: "Dorayaki",
    likedItems: ["Sunflower", "Watermelon", "Udon", "Napa Cabbage"],
  },
  {
    id: "shizuka",
    name: "Shizuka Minamoto",
    description: "Teman sekelas Nobita yang cerdas dan baik hati. Ia membantu di klinik desa.",
    location: "Klinik di Natura",
    favoriteItem: "Baked Sweet Potato",
    likedItems: ["Cheesecake", "P. Daisy", "Sweet Potato", "Yam"],
  },
  {
    id: "gian",
    name: 'Takeshi "Gian" Goda',
    description:
      "Teman sekelas Nobita yang kuat dan sering galak, namun memiliki sisi lembut. Ia menjadi magang di toko tukang kayu.",
    location: "Toko tukang kayu di hutan",
    favoriteItem: "Curry",
    likedItems: ["Stew", "Normal Wood", "Migratory Locust", "Green Pepper"],
  },
  {
    id: "suneo",
    name: "Suneo Honekawa",
    description: "Teman sekelas Nobita yang sombong namun cerdas. Ia membantu di restoran desa.",
    location: "Restoran di Natura",
    favoriteItem: "Marlin Stew",
    likedItems: ["Truffled Egg", "Melon", "Truffle", "Diamond"],
  },
]

// Data kategori NPC
const npcCategories = [
  { id: "officials", name: "Pejabat Desa", color: "blue" },
  { id: "farmers", name: "Peternak", color: "green" },
  { id: "merchants", name: "Pedagang", color: "yellow" },
  { id: "services", name: "Penyedia Jasa", color: "purple" },
]

// Data NPC
const npcs = [
  {
    id: "harmo",
    name: "Harmo",
    description: "Wali kota Natura yang bijaksana dan ramah.",
    location: "Rumah Wali Kota di Natura",
    category: "officials",
  },
  {
    id: "ravi",
    name: "Ravi",
    description: "Bibi dari Harmo yang bijak dan penuh kasih sayang.",
    location: "Rumah Wali Kota di Natura",
    category: "officials",
  },
  {
    id: "vera",
    name: "Vera",
    description:
      "Dikenal sebagai dewi oleh penduduk desa, sebenarnya adalah ilmuwan dari masa depan yang terdampar di Natura.",
    location: "Akar Pohon Besar di Natura",
    category: "officials",
    favoriteItem: "Compote",
    likedItems: ["Cabbage", "Yogurt", "Red Rose", "Strange Food"],
  },
  {
    id: "lanch",
    name: "Lanch",
    description: "Anak laki-laki yang pertama kali bertemu dengan Nobita dan teman-temannya di Natura.",
    location: "Rumah di dekat pertanian",
    category: "officials",
  },
  {
    id: "cooper",
    name: "Cooper",
    description: "Pemilik peternakan ayam yang rajin dan berdedikasi.",
    location: "Peternakan ayam di Natura",
    category: "farmers",
    favoriteItem: "Horned Atlas",
    likedItems: ["Strawberry Milk", "Mantis", "Mayonnaise", "Honeybee"],
  },
  {
    id: "helen",
    name: "Helen",
    description: "Ibu dari Cooper yang membantu mengelola peternakan ayam.",
    location: "Peternakan ayam di Natura",
    category: "farmers",
    favoriteItem: "Walnut Bread",
    likedItems: ["Caramel Almonds", "Strawberry", "Goldfish", "Egg"],
  },
  // Tambahkan NPC lainnya sesuai kebutuhan
]

export default function KarakterPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center">Karakter</h1>

      {/* Karakter Utama */}
      <section className="mb-12">
        <h2 className="section-title">Karakter Utama</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-6">
          {mainCharacters.map((character) => (
            <div key={character.id} className="character-card">
              <div className="relative h-48 bg-blue-50">
                <Image
                  src={`/placeholder.svg?height=200&width=400&text=${character.name}`}
                  alt={character.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{character.name}</h3>
                <p className="text-gray-600 mb-4">{character.description}</p>

                <div className="mb-4">
                  <span className="text-sm font-semibold text-gray-500">Lokasi:</span>
                  <p>{character.location}</p>
                </div>

                <div className="mb-4">
                  <span className="text-sm font-semibold text-gray-500">Item Favorit:</span>
                  <p className="font-medium text-green-600">{character.favoriteItem}</p>
                </div>

                <div>
                  <span className="text-sm font-semibold text-gray-500">Item yang Disukai:</span>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {character.likedItems.map((item, index) => (
                      <span key={index} className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* NPC */}
      <section>
        <h2 className="section-title">Penduduk Desa (NPC)</h2>

        <div className="flex flex-wrap gap-3 mb-6">
          <button className="px-4 py-2 rounded-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium">
            Semua
          </button>

          {npcCategories.map((category) => (
            <button
              key={category.id}
              className={`px-4 py-2 rounded-full bg-${category.color}-100 hover:bg-${category.color}-200 text-${category.color}-800 font-medium`}
            >
              {category.name}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {npcs.map((npc) => (
            <div
              key={npc.id}
              className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-4 border border-gray-100"
            >
              <h3 className="font-bold text-lg mb-1">{npc.name}</h3>
              <p className="text-sm text-gray-600 mb-3">{npc.description}</p>

              <div className="text-xs text-gray-500 mb-1">Lokasi:</div>
              <p className="text-sm mb-3">{npc.location}</p>

              {npc.favoriteItem && (
                <>
                  <div className="text-xs text-gray-500 mb-1">Item Favorit:</div>
                  <p className="text-sm font-medium text-green-600 mb-2">{npc.favoriteItem}</p>
                </>
              )}

              {npc.likedItems && (
                <>
                  <div className="text-xs text-gray-500 mb-1">Item yang Disukai:</div>
                  <div className="flex flex-wrap gap-1">
                    {npc.likedItems.map((item, index) => (
                      <span key={index} className="bg-blue-50 text-blue-700 text-xs px-2 py-0.5 rounded">
                        {item}
                      </span>
                    ))}
                  </div>
                </>
              )}
            </div>
          ))}
        </div>

        <div className="mt-8 text-center">
          <button className="btn btn-primary">Lihat Semua Penduduk</button>
        </div>
      </section>
    </div>
  )
}
